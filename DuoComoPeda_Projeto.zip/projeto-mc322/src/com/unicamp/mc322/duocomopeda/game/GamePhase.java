package com.unicamp.mc322.duocomopeda.game;

public enum GamePhase {
    MAIN, COMBAT;
}
