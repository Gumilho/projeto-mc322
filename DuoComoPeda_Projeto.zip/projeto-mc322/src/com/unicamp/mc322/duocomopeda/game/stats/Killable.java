package com.unicamp.mc322.duocomopeda.game.stats;

public interface Killable {

    public void die();

}