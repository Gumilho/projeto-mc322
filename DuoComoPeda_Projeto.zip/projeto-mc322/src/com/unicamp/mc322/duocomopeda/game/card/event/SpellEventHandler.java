package com.unicamp.mc322.duocomopeda.game.card.event;

import com.unicamp.mc322.duocomopeda.game.card.Card;

public interface SpellEventHandler {

    public void onPlay(Card playedCard);

}
