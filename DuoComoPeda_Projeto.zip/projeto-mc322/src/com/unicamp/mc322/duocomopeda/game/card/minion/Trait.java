package com.unicamp.mc322.duocomopeda.game.card.minion;

public enum Trait {
    ELUSIVE, 
    DOUBLE_ATTACK, 
    FURY
}
